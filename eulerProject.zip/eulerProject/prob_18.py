# node: value, id[level, index]
# node[i,i] -> node[i+1, j], node[i+1, j+1] 
import math
import numpy as np
from time import perf_counter

t0 = perf_counter()
nodes = [
    [75],
    [95, 64],
    [17, 47, 82],
    [18, 35, 87, 10],
    [20, 4, 82, 47, 65],
    [19, 1, 23, 75, 3, 34],
    [88, 2, 77, 73, 7, 63, 67],
    [99, 65, 4, 28, 6, 16, 70, 92],
    [41, 41, 26, 56, 83, 40, 80, 70, 33],
    [41, 48, 72, 33, 47, 32, 37, 16, 94, 29],
    [53, 71, 44, 65, 25, 43, 91, 52, 97, 51, 14],
    [70, 11, 33, 28, 77, 73, 17, 78, 39, 68, 17, 57],
    [91, 71, 52, 38, 17, 14, 91, 43, 58, 50, 27, 29, 48],
    [63, 66, 4, 68, 89, 53, 67, 30, 73, 16, 69, 87, 40, 31],
    [4, 62, 98, 27, 23, 9, 70, 98, 73, 93, 38, 53, 60, 4, 23]
]

def dec_to_bin(n, bin = [0,0,0,0,0,0,0,0,0,0,0,0,0,0]):
    if n == 0:
        return bin
    a = int(math.log2(n))
    bin[a] = 1
    n -= int(2**a)
    return dec_to_bin(n, bin)

def do_path(code, nodes):
    sum = nodes[0][0]
    previous_index = 0
    for j in range(1, len(nodes)):
        index = code[j-1    ] + previous_index
        sum += nodes[j][index]
        previous_index = index
    return sum

max_sum = 0
for i in range(0, (2**(len(nodes) -1 ))):
    code = dec_to_bin(i, bin = [0,0,0,0,0,0,0,0,0,0,0,0,0,0])
    sum = do_path(code, nodes)
    if sum > max_sum:
        max_sum = sum

print(max_sum) 
print(perf_counter()-t0)