# lado: 1, 3, 5, 7, 9, 11 ...
# números acrescentados: 4*lado - 4. 
# Por ex: para 5 de lado temos 16 números acrescentados  

# Primeiro: contagem + lado - 1
# Segundo: contagem + lado*2 - 2
# Terceiro: contagem + lado*3 - 3
# Quarto: contagem + lado*4 - 4
from time import perf_counter
t0 = perf_counter()
sum = 101
count = 25

for side in range(7, 1_002, 2):
    sum += 4*count + 10*side - 10
    count += 4*side - 4
print(sum)
print("Time: "+str(perf_counter()-t0))
