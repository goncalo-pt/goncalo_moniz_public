days = ["mon","tues","wed","thurs","fri","sat","sun"]
month_size = [31,28,31,30,31,30,31,31,30,31,30,31]
count=0
first_day=1
year = 1901
stop=False
while True:
    if stop: 
        break
    for month in range(0, 12):
        if year == 2000 and month == 11:
            stop=True
            break        
        if year%4 == 0 and month == 1: 
            first_day = (first_day + (month_size[month]+1)%7) % 7
        else:
            first_day = (first_day + month_size[month]%7) % 7
        print(days[first_day])
        if first_day == 6:
            count += 1
    year += 1

print(count)