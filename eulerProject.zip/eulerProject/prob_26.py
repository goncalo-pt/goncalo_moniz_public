# Find the value of d < 1000 for which 1/d contains the longest recurring cycle in its decimal fraction part.
from time import perf_counter
from decimal import *
t0 = perf_counter() 
places = 20_000
getcontext().prec = places

# returns True for a string with several consecutive equal 
# susbtrings (cycle) starting at index
def is_cycle(string, index, cycle):
    for i in range(1, 6):
        if not(string[index + i*len(cycle): index + i*len(cycle) + len(cycle)] == cycle):
            return False
    return True

def cycle_size(string):
    for start in range(0, 50):
        for size in range(1, 2_000):
            if is_cycle(string, start, string[start:start+size]):
                return size

buffer_pair = {"number":7, "size":6} # 1/7 has a cycle of 6 digits
skip = False
for d in range(8, 1_000):
    n = Decimal(1) / Decimal(d)
    n = str(n)[2:]
    if len(n) < places: 
        skip = True
    else: 
        skip = False
    if not(skip):
        size = cycle_size(n)
        if size > buffer_pair["size"]:
            buffer_pair["size"] = size
            buffer_pair["number"] = d
print(buffer_pair)
print("Time: "+str(perf_counter()-t0))        





