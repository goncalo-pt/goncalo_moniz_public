from math import factorial as fl
from time import perf_counter
t0 = perf_counter()
digits = [0,1,2,3,4,5,6,7,8,9]

def nth_digit(n, digits, number=[None]*10, entry=0):
    digit_index = int(n / fl(len(digits)-1))
    n -= digit_index * fl(len(digits)-1)
    number[entry] = digits[digit_index]
    digits.pop(digit_index)
    entry += 1
    if number[-1] is not None: 
        return number
    else:
        return nth_digit(n, digits, number, entry)
    
result = nth_digit(n=999_999, digits=digits)
number = ""
for i in range(len(result)):
    number += str(result[i])
print(number)
print("Time: "+str(perf_counter()-t0))