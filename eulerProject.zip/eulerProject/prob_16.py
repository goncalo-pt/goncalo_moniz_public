n = str(2**1000)
sum=0
for i in range(len(n)):
    sum += int(n[i])
print(sum)