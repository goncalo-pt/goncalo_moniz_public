from math import factorial
n = factorial(100)

sum=0

for i in range(0, len(str(n))):
    sum += int(str(n)[i])

print(sum)