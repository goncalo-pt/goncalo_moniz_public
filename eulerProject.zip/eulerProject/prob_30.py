def check_(number):
    sum = 0
    for i in range(0, len(str(number))):
        sum += int(str(number)[i])**5
        if sum > number: return False
    if sum == number: 
        return True
    else:
        return False

number = 10
sum = 0
while True:
    if check_(number):
        sum += number
    number += 1
    max_powers = 9**5 * len(str(number))
    if max_powers < number:
        break
print(sum)