from math import log2
from time import perf_counter
t=perf_counter()
# Convert from decimal to binary.
# MSB on right
def dec_to_binary(n):
    if n == 0:
        return "0"
    index = int(log2(n)) + 1
    string = [0]*index
    string[index-1] = 1
    n -= 2**(index-1)
    while n > 0:
        index = int(log2(n))
        string[index] = 1
        n -= 2**index
    string_ = ""
    for i in range(len(string)):
        string_ += str(string[i])
    return string_


def is_palindrome(n):
    n = str(n)
    if len(n) == 1:
        return True
    for i in range(int(len(n)/2)):
        if n[i] != n[len(n)-i-1]:
            return False
    return True

sum=0
for j in range(0, 1_000_000):
    if is_palindrome(j) and is_palindrome(dec_to_binary(j)):
        sum += j
print(sum)
print("time: "+str(perf_counter()-t))