from time import perf_counter
t=perf_counter()

def is_pandigital(n):
    n_ = str(n)
    for i in range(len(n_)):
        if int(n_[i]) == 0 or int(n_[i]) > len(n_) or n_.count(n_[i]) > 1:
            return False
    return True 

def is_prime(n):
    for i in range(2, int(n**0.5 +1)):
        if n%i == 0:
            return False
    return True

def prime_sieve(n):
    unmarked = list(range(2, n))
    marked = []
    p=2
    while max(unmarked) > p: 
        for i in range(2*p, n, p):
            if i not in marked:
                marked.append(i)
                unmarked.remove(i)
        p = unmarked[unmarked.index(p) + 1]
    return unmarked 

from math import factorial as fl
def permutations(n):
    permutations_ = [None]*fl(n)
    for p in range(0, fl(n)):
        digits = list(range(1, n+1))
        perm = ""
        k=0
        index = 0
        for _ in range(0, n):
            combinations = fl(n - len(perm))
            bin_size = combinations / (n - len(perm)) 
            k += index * combinations                        
            index = int((p-k) / bin_size)
            perm += str(digits.pop(index))
        permutations_[p] = perm
    return permutations_

n = 1_000_000_000
perms = []
for j in range(4, 10):
    perms.append(permutations(j))

max_prime_pan = 0
for i in range(len(perms)):
    for j in range(len(perms[i])):
        if is_prime(int(perms[i][j])) and int(perms[i][j]) > max_prime_pan:
            max_prime_pan = int(perms[i][j])  

print(max_prime_pan)
print("time: "+str(perf_counter()-t))