from time import perf_counter
t0 = perf_counter()
num_ways = 1
def is_natural(n):
    if n >= 0 and type(n) is int:
        return True
    return False


for b in range(0, 101):
    for c in range(0, 41):
        for d in range(0, 21):
            for e in range(0, 11):
                for f in range(0, 5):
                    for g in range(0, 3):
                        a = 200 - (b*2 + c*5 + d*10 + e*20 + f*50 + g*100) 
                        if is_natural(a):
                            num_ways += 1

print(num_ways)                            
print("Time: "+str(perf_counter()-t0))