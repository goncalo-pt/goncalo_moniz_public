from time import perf_counter
t = perf_counter()
# Open the text file
with open('p042_words.txt', 'r') as file:
    # Read the contents
    content = file.read()

# Split the content using the comma delimiter
split_strings = content.split(',')

# Create a list from the split strings
word_list = list(split_strings)

alphabet = {}
# Adding key-value pairs to the dictionary using a loop
for i in range(26):
    letter = chr(ord('A') + i)  # Get the letter corresponding to the current index
    value = i + 1  # Numeric value is index + 1
    alphabet[letter] = value

def value(word, alphabet):
    value = 0
    for letter in range(len(word)):
        value += alphabet[word[letter]]
    return value

def check(number):
    n0 = (-1+(1+8*number)**0.5) / (2)
    if n0.is_integer() and n0 > 0:
        return True
    n0 = (-1-(1+8*number)**0.5) / (2)
    if n0.is_integer() and n0 > 0:
        return True
    return False

count = 0

for word in word_list:
    if check(value(word, alphabet)):
        count += 1
print(count)
print("time: "+str(perf_counter()-t))
