# What is the smallest positive number that is evenly divisible by all of the numbers from 1 to 20?

"""
even
ends in 0
> 2520
multiple of 20

"""

def check_condition(n):
    for i in range(1, 21):
        if n%i != 0:
            return False
    return True

n=2520
while True:
    if check_condition(n):
        print(n)
        break
    n += 20