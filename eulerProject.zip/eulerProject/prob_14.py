def collatz(n):
    sequence = [n]
    while sequence[-1] != 1:
        if sequence[-1]%2 == 0:
            sequence.append(int(sequence[-1]/2))
        else:
            sequence.append(int(1+3*sequence[-1]))
    return sequence


max_seq = 10
max_seq_starter = 13
for i in range(13, 1_000_000):
    seq_len = len(collatz(i))
    if seq_len > max_seq:
        max_seq = seq_len
        max_seq_starter = i

print(max_seq_starter)