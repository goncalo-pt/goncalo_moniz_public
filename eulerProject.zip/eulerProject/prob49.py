def are_permutations(a, b):
    a = str(a)
    b = str(b)
    for i in range(10):
        if a.count(str(i)) !=  b.count(str(i)):
            return False
    return True
        
primes = list(range(2, 10_000))
p=primes[0]
n=0
while p < max(primes):
    for i in range(2*p, 10_000, p):
        if i in primes:
            primes.remove(i) 
    n += 1
    p = primes[n]

for i in reversed(range(len(primes))):
    if primes[i] < 1000:
        primes.pop(i)


def check(primes):
    for i in range(len(primes)):
        perms = [primes[i]]
        for j in range(i+1, len(primes)):
            if are_permutations(primes[i], primes[j]):
                perms.append(primes[j])
        if len(perms) > 2:
            perms.sort()
            for l in range(0, len(perms)-2):
                for t in range(l+1, len(perms)-1):
                    for a in range(t+1, len(perms)):
                        if perms[t] - perms[l] == perms[a] - perms[t]:
                            print(str(perms[l])+str(perms[t])+str(perms[a]))
                        

check(primes)