def triangle(i):
    return (i**2 + i) / 2

def is_pentagonal(y):
    n = (1+(1+24*y)**0.5) / 6
    if n.is_integer() and n > 0:
        return True
    n = (1-(1+24*y)**0.5) / 6
    if n.is_integer() and n > 0:
        return True
    return False

def is_hexagonal(y):
    n = (1+(1+8*y)**0.5) / 4
    if n.is_integer() and n > 0:
        return True
    n = (1-(1+8*y)**0.5) / 4
    if n.is_integer() and n > 0:
        return True
    return False

i=286
while True:
    y = triangle(i)
    if is_hexagonal(y) and is_pentagonal(y):
        print(y)
        break
    i += 1
