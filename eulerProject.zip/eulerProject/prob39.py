from time import perf_counter

t = perf_counter()

def check(a, p):
    b = (p**2 - 2*a*p) / (2*p - 2*a)
    if not(b.is_integer()):
        return False
    c = (b**2 + a**2)**0.5
    if not(c.is_integer()):
        return False
    return True

max_count = 0

for p in range(4, 1_001):
    count = 0
    for a in range(1, p-2):
        if check(a, p):
            count += 1
    if count > max_count:
        max_count = count
        max_p = p

print(max_p)
print("time: "+str(perf_counter()-t))