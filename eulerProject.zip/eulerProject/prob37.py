def is_prime(n):
    if n==1:
        return False
    if n == 2 or n == 3:
        return True
    for i in range(2, int(n**0.5+1)):
        if n%i == 0:
            return False
    return True 

sum=0
count=0
i=11
def trunc_primes(i, count):
    if is_prime(i):
        i_ = str(i)
        for d in range(1, int(len(i_))):
            if not(is_prime(int(i_[d:]))):
                return 0, count
        for d in range(int(len(i_))-1, 0, -1):
            if not(is_prime(int(i_[:d]))):
                return 0, count
        count += 1
        return i, count
    return 0, count

while count < 11:
    sum += trunc_primes(i, count)[0]
    count = trunc_primes(i, count)[1]
    i += 1

print(sum)