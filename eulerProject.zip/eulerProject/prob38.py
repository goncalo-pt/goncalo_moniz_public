from math import factorial as fl
from time import perf_counter

t=perf_counter()

def nine_digit_permutations(i):
    digits = [1,2,3,4,5,6,7,8,9]
    perm = ""
    k = 0
    for _ in range(0, 9):
        num_comb = fl(9-len(perm)) 
        bin_size = num_comb / (9 - len(perm))
        index = digits.pop(int((i-k) / bin_size))        
        k += int((i-k) / bin_size) * bin_size
        perm += str(index)
    return perm


def check(n_):
    if int(n_[3:6]) == 2*int(n_[0:3]) and int(n_[6:]) == 3*int(n_[0:3]):
        return True
    if int(n_[4:]) == 2*int(n_[0:4]):
        return True
    if int(n_[2:4]) == 2*int(n_[0:2]) and int(n_[4:6]) == 3*int(n_[0:2]
        ) and int(n_[6:]) == 4*int(n_[0:2]):
        return True    
    return False


largest = 0

for j in range(0, fl(9)):
    if check(nine_digit_permutations(j)) and int(nine_digit_permutations(j)) > largest:
        largest = int(nine_digit_permutations(j))

print(largest)
print("time: "+str(perf_counter()-t))