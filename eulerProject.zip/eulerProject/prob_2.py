buffer0=1
buffer1=1
value = 1
sum=0
while True:
    value = buffer0 + buffer1
    if value > 4000000:
        break
    if value%2 == 0:
        sum += value
    buffer1 = buffer0
    buffer0 = value
    
print(sum)
