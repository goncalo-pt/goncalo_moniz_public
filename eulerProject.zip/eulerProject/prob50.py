from math import factorial as fl

# Python3 program to generate all
# prime numbers less than N in O(N)

def manipulated_seive(N):
    MAX_SIZE = N+1
    isprime = [True] * MAX_SIZE
    prime = []
    SPF = [None] * (MAX_SIZE)

    # 0 and 1 are not prime
    isprime[0]=False
    isprime[1] = False
    for i in range(2, N):
        if isprime[i] == True:
            prime.append(i)
            SPF[i] = i
        j = 0
        while (j < len(prime) and i * prime[j] < N and prime[j] <= SPF[i]):	
            isprime[i * prime[j]] = False
            # put smallest prime factor of i*prime[j]
            SPF[i * prime[j]] = prime[j]
            j += 1
    return prime

def permutations(list, chain):
    total_size = int(fl(len(list)) / fl(len(list) - chain))
    permutations_ = []
    for p in range(total_size):
        elements_list = list.copy()
        perm = []
        k = 0
        index = 0
        for _ in range(chain):
            total_size = fl(len(elements_list)) / fl(len(elements_list) - (chain - len(perm)))
            bin_size = total_size / len(elements_list)
            k += index * total_size
            index = int((p-k)/bin_size)
            perm.append(elements_list.pop(index))
        permutations_.append(perm)
    return permutations_

def combinations(list_, chain_size):
    num_combinations = int(fl(len(list_)) / (fl(chain_size)*fl(len(list_)-chain_size)))
    bin_list = [None]*num_combinations
    current_string = [0]*len(list_)
    current_string[0:chain_size] = [1]*chain_size
    bin_list[0] = current_string.copy()
    c = 0
    # Generate binary lists that represent combinations where order does not matter
    while bin_list[-1] is None:
        c += 1
        for i in range(len(list_)-2, -1, -1):
            if current_string[i] == 1 and current_string[i+1] == 0:
                one_to_increment = i
                ones_to_reset = current_string[one_to_increment+1:].count(1)
                break
        current_string[one_to_increment] = 0
        current_string[one_to_increment+1] = 1
        if ones_to_reset > 0:
            current_string[one_to_increment+2:] = [0]*(len(list_)-one_to_increment-2)
            for j in range(ones_to_reset):
                current_string[one_to_increment+2+j] = 1 
        bin_list[c] = current_string.copy()
    # Decode binary strings to actual combinations using the elements of list_
    comb_list = [None]*num_combinations
    for c in range(num_combinations):
        comb = []
        for i in range(len(list_)):
            if bin_list[c][i] == 1:
                comb.append(list_[i])
        comb_list[c] = comb
    return comb_list
a=combinations(["A", "B", "C", "D", "E"], 3)
print(a)
# get all prime chains with size equal to chain size 
def prime_chains(primes, chain_size):
    chains = [None]*(1 + len(primes)-chain_size)
    for c in range(len(chains)):
        chain = primes[c:c+chain_size]
        chains[c] = chain
    return chains


def check(prime, primes_list, chain_size, max_prime):
    max_chain_prime = max_prime
    max_chain = chain_size
    chain_size += 1
    while True:        
        sum_ = 0
        for i in range(chain_size):
            sum_ += primes_list[i]
            if sum_ > prime:
                return max_chain, max_chain_prime 
        combinations_ = prime_chains(primes_list, chain_size)
        for c in combinations_:
            prime_sum = sum(c)
            if prime_sum == prime:
                max_chain = chain_size
                max_chain_prime = prime
        chain_size += 1

def check_(chain_size, primes):
    size = chain_size+1
    max_chain = chain_size
    while sum(primes[0:size]) < max(primes):
        for i in range(0, len(primes) - size + 1):
            if sum(primes[i:i+size]) in primes:
                max_chain = size
                max_prime = sum(primes[i:i+size])
                break
            if sum(primes[i:i+size]) > max(primes):
                break
        size += 1

    return max_chain, max_prime

max_chain = 6
max_chain_prime = 41

primes = manipulated_seive(1_000_000)
for n in range(100_000, 1_100_000, 100_000):
    primes_ = [x for x in primes if x < n]
    max_chain, max_chain_prime = check_(max_chain, primes_)

print(max_chain_prime) 