from time import perf_counter
t=perf_counter()
def is_composite(i):
    for j in range(2, int(i**0.5+1)):
        if i%j == 0:
            return True
    return False

def prime_sieve(n):
    unmarked = list(range(2, n))
    marked = []
    p=2
    while max(unmarked) > p: 
        for i in range(2*p, n, p):
            if i not in marked:
                marked.append(i)
                unmarked.remove(i)
        p = unmarked[unmarked.index(p) + 1]
    return unmarked 

def check(i, primes):
    #primes = prime_sieve(i)
    for p in primes:
        if (((i - p) / 2)**0.5).is_integer():
            return True
    return False

i=35
primes = prime_sieve(35)
while check(i, primes):
    i += 2
    while not(is_composite(i)):
        primes.append(i)
        i += 2
    
print(i)
print("time: "+str(perf_counter()-t))