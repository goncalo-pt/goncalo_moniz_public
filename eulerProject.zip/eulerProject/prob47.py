from time import perf_counter
t=perf_counter()

def prime_factors(j):
    factors = []
    explore = [j]
    while len(explore) > 0:
        skip = False
        if explore[0] == 2 or explore[0] == 3:
            factors.append(explore.pop(0))
        else:        
            upper = int(1+explore[0]**0.5)
            for k in range(2, upper):
                if explore[0]%k == 0:
                    p = explore.pop(0)
                    explore.append(int(p/k))
                    explore.append(k)
                    skip = True
                    break
            if not(skip):
                factors.append(explore.pop(0))
    factors_list = []
    for factor in factors:
        count = factors.count(factor)
        factors_list.append(str(factor)+f"^{count}")
    return set(factors_list)

def check(n, factors_dict):
    factors = [list]*4
    # get prime factors for 4 numbers
    for i in range(4):
        if n+i in factors_dict:
            factors[i] = factors_dict[n+i]
        else:
            factors[i] = prime_factors(i+n)
            factors_dict[i+n] = factors[i]
    if len(factors[0]) > 3 and len(factors[1]) > 3 and len(factors[2]) > 3 and len(factors[3]) > 3: 
        return True, factors_dict
    return False, factors_dict

factors_dict = {644:set(["2^2","7^1","23^1"]), 645:set(["3^1","5^1","43^1"]), 646:set(["2^1","17^1","19^1"])}

n=644
while not(check(n, factors_dict)[0]):
    n += 1
print(n)
print("time: "+str(perf_counter()-t))