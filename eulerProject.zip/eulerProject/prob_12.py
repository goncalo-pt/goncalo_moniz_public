# What is the value of the first triangle number to have over five hundred divisors?
def decompose(n):
    divisors = [1, n]
    for i in range(2, int(2+n**0.5)):
        if n%i == 0:
            if i not in divisors:
                divisors.append(i)
            if int(n/i) not in divisors:
                divisors.append(int(n/i))
    return  len(set(divisors))

k = 7
sum = 28
while True:
    num_divisors = decompose(sum)
    #print(num_divisors)
    if num_divisors > 500:
        print("Result: "+str(sum))
        break 
    k += 1
    sum += k
