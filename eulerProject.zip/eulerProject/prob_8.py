string_list = []
string_list.append("7316717653133")
string_list.append("6249192251196744265747423553491949349698352")
string_list.append("6326239578318")
string_list.append("18694788518438586156")
string_list.append("7891129494954595")
string_list.append("17379583319528532")
string_list.append("698747158523863")
string_list.append("963295227443")
string_list.append("435576689664895")
string_list.append("4452445231617318564")
string_list.append("987111217223831136222989342338")
string_list.append("81353362766142828")
string_list.append("64444866452387493")
string_list.append("1724271218839987979")
string_list.append("9377665727333")
string_list.append("594752243525849")
string_list.append("48395864467")
string_list.append("632441572215539753697817977846174")
string_list.append("86256932197846862248283972241375657")
string_list.append("79729686524145351")
string_list.append("4748216637")
string_list.append("6585412275886668811642717147992444292823")
string_list.append("863465674813919123162824586178664583591245665294765456828489128831426")
string_list.append("96245544436298123")
string_list.append("9878799272442849")
string_list.append("979191338754992")
string_list.append("559357297257163626956188267")


from functools import reduce

def find_max_product(list):
    if len(list) <= 13:
        return reduce(lambda x, y: x * y, list)
    max_prod = 1
    for j in range(0, len(list)-12):
        prod = reduce(lambda x, y: x * y, list[j:j+13])
        if prod > max_prod:
            max_prod = prod
    return max_prod

largest_value = 1

def string_to_list(string):
    list = [int]*len(string)
    for k in range(0, len(string)):
        list[k] = int(string[k])
    return list


for i in range(0, len(string_list)):
    list = string_to_list(string_list[i])
    value = find_max_product(list)
    if value > largest_value:
        largest_value = value

print(largest_value)

# 