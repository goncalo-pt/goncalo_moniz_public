# generate a b space
pairs = []
for a in range(2, 101):
    for b in range(2, 101):
        pairs.append([a, b])

list_ = [None]*len(pairs)

for pair in range(len(pairs)):
    list_[pair] = pairs[pair][0]**(pairs[pair][1])

my_set = set(list_)
print(len(my_set)) 