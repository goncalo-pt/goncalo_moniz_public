from math import trunc

def is_palindrome(number):
    number = str(number)  
    checks = trunc(len(number) / 2)
    for i in range(0, checks):
        if number[i] != number[len(number)-1-i]:
            return False # is not a palindrome
    return True # is palindrome  

def have_3_digits(n1, n2):
    if len(str(n1)) == 3 and len(str(n2)) == 3:
        return True
    else:
        return False

def decompose(number):
    for j in range(100, 1000):
        if number%j == 0 and have_3_digits(int(number/j), j):
            num0 = j
            num1 = int(number/j)
            print(str(num0) + " x " + str(num1) + " = " + str(num0*num1))
            return have_3_digits(num0, num1)

for n in reversed(range(999**2)):
    r = is_palindrome(n)
    if r and decompose(n):
        break

    