buffer0=1
buffer1=1

def n_digits(value):
    number = len(str(value))
    return number
index=2
while True:
    value = buffer0 + buffer1
    index += 1
    if n_digits(value) == 1_000:
        break
    buffer1 = buffer0
    buffer0 = value

print(index)

