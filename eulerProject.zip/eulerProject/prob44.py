def pentagonal(n):
    n+=1
    return n*(3*n-1) / 2

def is_pentagonal(y):
    n = (1+(1+24*y)**0.5) / 6
    if n.is_integer() and n > 0:
        return True
    n = (1-(1+24*y)**0.5) / 6
    if n.is_integer() and n > 0:
        return True
    return False

list_ = [1,5,12,22]

n = 4
stop=False
while True:
    for i in range(n-1, -1, -1):
        if is_pentagonal(pentagonal(n)-pentagonal(i)) and is_pentagonal(pentagonal(n)+pentagonal(i)):
            print(pentagonal(n)-pentagonal(i))
            stop=True
            break 
    if stop: 
        break
    n += 1