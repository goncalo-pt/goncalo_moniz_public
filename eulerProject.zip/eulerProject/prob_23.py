# perfect number: sum of proper divisors is equal to the number
# Ex: 1 + 2 + 4 + 7 + 14 = 28, which means that 28 is a perfect number
# A number n is called deficient if the sum of its proper divisors is 
# less than n and it is called abundant if this sum exceeds n.
# All integers greater than 28123 can be written as the sum of two abundant numbers

from time import perf_counter

t0 = perf_counter()

def sum_list(list):
    sum = 0
    for i in range(len(list)):
        sum += list[i]
    return int(sum)

def is_abundant(n):
    divisors = [1]
    for i in range(2, int(n**0.5+1)):
        if n%i == 0:
            divisors.append(i)
            if i != int(n/i):
                divisors.append(int(n/i))
    sum = sum_list(divisors)
    if sum > n:
        return True
    else: return False

abundants_list = []

int_list = []
for k in range(1, 28124):
    int_list.append([k, False])

for i in range(5, 28123):
    if is_abundant(i):
        abundants_list.append(i)
        for j in range(len(abundants_list)):
            if abundants_list[j] + i < 28124:
                int_list[abundants_list[j] + i - 1][1] = True
'''
for k in range(len(abundants_list)):
    for j in range(k, len(abundants_list)):
        if abundants_list[j] + abundants_list[k] < 28124:
            int_list[abundants_list[j] + abundants_list[k] - 1][1] = True'''

sum = 0

for i in range(len(int_list)):
    if not(int_list[i][1]):
        sum += int_list[i][0]
print(sum) 
print("Time: "+str(perf_counter()-t0))
