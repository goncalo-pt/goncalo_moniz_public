# Find the sum of all the primes below two million.
from time import perf_counter
t0 = perf_counter()

def is_prime(n):
    if n == 2:
        return True
    for i in range(2, int(2+n**0.5)):
        if n%i == 0:
            return False # not prime
    return True # is prime

sum = 0

for n in range(2, 2_000_000):
    if is_prime(n):
        sum += n
        
print("Sum: "+str(sum))
print("time: "+str(perf_counter()-t0))