string=""
i = 1

while len(string) < 1_000_000:
    string += str(i)
    i += 1

print(int(string[99])*int(string[999])*int(string[9999])*int(string[99_999])*int(string[999_999])) 