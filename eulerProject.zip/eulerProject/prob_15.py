from numpy import array
import numpy as np
from collections import deque

size = int(5)
start_pos = array([0,0], dtype=int)
goal_pos = array([size,size], dtype=int)

moves = {"right":array([1,0]), "down":array([0,1])}

solutions = []
curr_solution = []
curr_pos = array([0,0])

def graph_search(root_pos=array([0,0], dtype=int)):
    curr_pos = root_pos.copy()
    curr_solution = []*size*2
    while np.any(curr_pos != goal_pos):
        if curr_pos[0] < size:
            curr_solution.append("right")
            curr_pos += moves["right"]
        else:
            curr_solution.append("down")
            curr_pos += moves["down"]

    return curr_solution

# Find first solution
first_solution = graph_search()
solutions.append(first_solution)

# Find mutations at every graph level
for level in range(0, int(size*2-1)):
    buffer_solutions = []
    for s in range(len(solutions)):
        skip = False
        solution = solutions[s][:level+1].copy()
        if solution[level] == "right" and solution.count("down") < size:
            solution[level] = "down" 
        elif solution[level] == "down" and solution.count("right") < size:
            solution[level] = "right"
        else: skip = True
        if not(skip):
            root_pos = array([solution.count("right"), solution.count("down")])
            if np.any(root_pos != goal_pos):
                mutation = graph_search(root_pos)
                result = solution + mutation 
                buffer_solutions.append(result)    
    solutions = solutions + buffer_solutions
print(len(solutions))    
















