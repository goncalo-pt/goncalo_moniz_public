sum=0

for i in range(1, 1001):
    sum += i**i
sum_ = str(sum) 
print(sum_[len(sum_)-10:])