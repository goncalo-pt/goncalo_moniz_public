def sum_all_factors(n):
    sum=1
    for i in range(2, int(n**0.5)+1):
        if n%i == 0:
            sum += i
            if i !=int(n/i): 
                sum += int(n/i)
    return sum

list = []
for j in range(1, 10_000):
    list.append([j, sum_all_factors(j), None])

sum=0
for j in range(0, len(list)):
    for k in range(j+1, len(list)):
        if list[j][0] == list[k][1] and list[j][1] == list[k][0]:
            list[j][2] = True
            list[k][2] = True
for i in range(0, len(list)):
    if list[i][2]:
        sum += list[i][0]
print(sum)


