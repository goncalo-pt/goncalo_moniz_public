"""The number, 197, is called a circular prime because all rotations of the digits: 
197, 971, and 719, are themselves prime.
There are thirteen such primes below 100: 2, 3, 5, 7, 11, 13, 17, 31, 37, 71, 73, 79, and 97.
How many circular primes are there below one million?"""

from math import factorial as fl
from time import perf_counter

t = perf_counter()

def permutations(n):
    n_ = str(n)
    perm_list = [int]*fl(len(n_))
    perm = []
    n_list = [int]*len(n_)
    for i in range(0, len(n_)):
        n_list[i] = n_[i]
    for p in range(0, int(fl(len(n_)))):
        perm = []
        index = 0
        k=0
        n_list_buffer = n_list.copy()
        for _ in range(0, len(n_)):
            total_size = fl(len(n_)-len(perm))
            bin_size = total_size / (len(n_)-len(perm))
            k += index * total_size
            index = int((p - k)/ bin_size)
            perm.append(n_list_buffer.pop(index))
        perm_list[p] = perm
    return perm_list


def rotations(n):
    n_ = str(n)
    rotations_ = [int]*len(n_)
    for i in range(len(n_)):
        rotation = n_[i]
        for d in range(1, len(n_)):
            rotation += n_[(i+d)%len(n_)]
        rotations_[i] = rotation
    return rotations_

def is_prime(n):
    for i in range(2, int(n**0.5+1)):
        if n%i == 0:
            return False
    return True


def is_circular_prime(n):
    if not(is_prime(n)):
        return False
    rotations_list = rotations(n)
    for p in range(len(rotations_list)):
        a = ""
        for j in range(len(rotations_list[p])):
            a += rotations_list[p][j]
        a = int(a)
        for i in range(2, int(a**0.5)):
            if a%i == 0:
                return False
    return True

count=13

for i in range(98, 1_000_000):
    if is_circular_prime(i):
        count += 1

print(count)
print("time: "+str(perf_counter()-t))