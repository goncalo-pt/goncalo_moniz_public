from time import perf_counter
t0 = perf_counter()

def is_prime(n):
    if n <= 0:
        return False
    if n == 2 or n==3: return True
    for i in range(2, int(n**0.5+1)):
        if n%i == 0: return False
    return True

def quadratic(a, b, n):
    return n**2 + a*n + b

# Generate coefficient space
coef = []

for a in range(-1_000, 1_000, 1):
    for b in range(-1_001, 1_001, 1):
        coef.append([a,b])

max_seq = 0
max_pair = 0
for pair in range(len(coef)):
    seq_size = 0
    n = 0
    while is_prime(quadratic(coef[pair][0], coef[pair][1], n)):
        seq_size += 1
        n += 1
    if seq_size > max_seq: 
        max_seq = seq_size 
        max_pair = coef[pair]
print(max_pair[0]*max_pair[1])
print("Time: "+str(perf_counter()-t0))