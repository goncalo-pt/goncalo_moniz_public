# There exists exactly one Pythagorean triplet for which a + b + c = 1000.
# Find the product abc.

def is_pyth_triplet(a, b):
    c = (a**2 + b**2)**0.5
    if abs(c - int(c)) == 0 and a+b+c == 1000:
        return True
    else:
        return False
    
break_flag = False   
for a in range(1, 999): # a
    if break_flag: 
        a += -1
        break
    for b in range(a+1, 1000): # b
        if is_pyth_triplet(a, b):
            result = a*b*((a**2 + b**2)**0.5)       
            break_flag = True 
            break

print("a: "+str(a)+", b: "+str(b)+", c: "+str((a**2 + b**2)**0.5))
print("a*b*c: "+str(result))