number=600_851_475_143
#number=13195
nodes_to_explore = []
leafs = []
nodes_to_explore.append(number)

def search_tree(nodes_to_explore, leafs):   
    for i in range(2, nodes_to_explore[0]+1):
        remainder = nodes_to_explore[0]%i
        if i == nodes_to_explore[0] or i > int(0.5*nodes_to_explore[0]+2):
                leafs.append(nodes_to_explore[0])
                nodes_to_explore.pop(0)
                if len(nodes_to_explore) == 0:
                    return leafs
                else:
                    return search_tree(nodes_to_explore, leafs) 
        elif remainder == 0:
            val0 = i
            val1 = int(nodes_to_explore[0] / i)
            nodes_to_explore.pop(0)
            if val0 != 2:
                nodes_to_explore.append(val0)
            if val1 != 2:
                nodes_to_explore.append(val1)
            if len(nodes_to_explore) == 0:
                leafs.append(val0)
                leafs.append(val1)
                return leafs
            return search_tree(nodes_to_explore, leafs)

factors = search_tree(nodes_to_explore, leafs)
largest = max(factors)
print(largest)

"""


         45
    15          3
  5    3

  

"""
