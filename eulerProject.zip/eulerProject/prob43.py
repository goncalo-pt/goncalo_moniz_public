from math import factorial as fl

def permutation_10digits(i):
    digits = [0,1,2,3,4,5,6,7,8,9]
    perm = ""
    k=0
    index = 0
    for _ in range(10):
        combinations = fl(10 - len(perm))
        bin_size = combinations / (10 - len(perm))
        k += index * combinations
        index = int((i-k)/bin_size)
        perm += str(digits.pop(index))
    return perm

def check(number):
    primes = [2,3,5,7,11,13,17]
    for i in range(1, 8):
        n = int(number[i:i+3])
        if not(n%primes[i-1]==0):
            return False
    return True

sum=0
#check("1406357289")
for p in range(0, fl(10)):
    if check(permutation_10digits(p)):
        sum += int(permutation_10digits(p))
print(sum)
