from time import perf_counter
t0 = perf_counter()
# Open the text file
with open('p022_names.txt', 'r') as file:
    # Read the contents
    content = file.read()

# Split the content using the comma delimiter
split_strings = content.split(',')

# Create a list from the split strings
my_list = list(split_strings)
alphabet = {}
# Adding key-value pairs to the dictionary using a loop
for i in range(26):
    letter = chr(ord('A') + i)  # Get the letter corresponding to the current index
    value = i + 1  # Numeric value is index + 1
    alphabet[letter] = value

def name_to_code(name, alphabet):
    code = [None]*len(name)
    for letter in range(len(name)):
        code[letter] = alphabet[name[letter]]
    return code

def compare_codes(code0, code1):
    for i in range(min(len(code0), len(code1))):
        if code0[i] < code1[i]:
            return 0
        elif code1[i] < code0[i]:
            return 1
    if len(code0) < len(code1):
        return 0
    else:
        return 1
    
code_list = [None]*len(my_list)
for name in range(len(my_list)):
    code_list[name] = [name_to_code(my_list[name], alphabet)]


# Merge Sort
def sort_and_merge(list0, list1):
    ordered_list = [None]*(len(list0)+len(list1))
    index = 0
    while len(list0) > 0 and len(list1) > 0:
        l = compare_codes(list0[0], list1[0])
        if l == 0:
            ordered_list[index] = list0[0]
            list0.pop(0)
        else:   
            ordered_list[index] = list1[0]
            list1.pop(0)
        index += 1
    if ordered_list[-1] is not None:
        return ordered_list
    else:
        if len(list0) > 0:
            remaining_list = list0.copy()
        else:
            remaining_list = list1.copy()
        for i in range(len(remaining_list)):
            ordered_list[index+i] = remaining_list[i]
        return ordered_list

sorting_list = code_list.copy()
#sorting_list = [[[38, 10]],[[27]],[[38,1]],[[43]],[[3]],[[3,1]],[[3,99]],[[9]],[[82]],[[10]]]
while len(sorting_list) > 1:
    buffer_list = []
    for i in range(0, len(sorting_list), 2):
        if i+1 < len(sorting_list):
            buffer_list.append(sort_and_merge(sorting_list[i], sorting_list[i+1]))
    if i == len(sorting_list)-1:
         buffer_list.append(sorting_list[-1])
    sorting_list = buffer_list.copy()

sum = 0

def sum_list_elements(l):
    sum=0
    for i in range(0, len(l)):
        sum += l[i]
    return sum

for name in range(len(sorting_list[0])): 
    sum += (name + 1) * (sum_list_elements(sorting_list[0][name]))
print(sum)
print("time: "+str(perf_counter()-t0))