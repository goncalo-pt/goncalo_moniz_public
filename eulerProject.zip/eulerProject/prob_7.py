# What is the 10 001st prime number?

def is_prime(n):
    if n == 2:
        return True
    for i in range(2, n+1):
        if (n%i == 0 and n!=i):
            return False
        elif (n%i == 0 and n==i) or i > int(n**0.5+2):
            return True
        
num_of_primes = 6
n=14
while True:
    if n%2 != 0:    
        if is_prime(n):
            num_of_primes += 1
            if num_of_primes == 10_001:
                print(n)
                break
    n += 1